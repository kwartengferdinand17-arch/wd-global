import { pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

// ─────────────────────────────────────────────────────────────────────────────
// DATABASE TABLE: "enquiries"
// Every booking / contact message a visitor sends is stored here as one row.
// ─────────────────────────────────────────────────────────────────────────────
export const enquiries = pgTable("enquiries", {
  id: serial("id").primaryKey(), // auto-increasing number: 1, 2, 3 …
  name: varchar("name", { length: 120 }).notNull(), // visitor's full name
  email: varchar("email", { length: 160 }).notNull(), // visitor's email
  phone: varchar("phone", { length: 40 }).notNull(), // visitor's phone number
  service: varchar("service", { length: 80 }).notNull(), // what they need help with
  preferredDate: varchar("preferred_date", { length: 40 }), // date they want a visit/call
  message: text("message").notNull(), // the message they typed
  status: varchar("status", { length: 20 }).notNull().default("new"), // new / contacted / done
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// Helpful TypeScript types derived automatically from the table above.
export type Enquiry = typeof enquiries.$inferSelect;
export type NewEnquiry = typeof enquiries.$inferInsert;
