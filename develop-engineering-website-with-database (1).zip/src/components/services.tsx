import {
  ArrowUpRight,
  Building2,
  Cable,
  ClipboardCheck,
  HardHat,
  Landmark,
  MapPinned,
  PenTool,
  type LucideIcon,
} from "lucide-react";
import { SERVICES } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

// Map the icon name stored in site.ts to the actual Lucide component.
const ICONS: Record<string, LucideIcon> = {
  Landmark,
  PenTool,
  HardHat,
  ClipboardCheck,
  MapPinned,
  Cable,
  Building2,
};

// "02 / SERVICES" — the six things the company does, as interactive cards.
export function Services() {
  return (
    <section id="services" className="scroll-mt-20 border-t border-line py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-8">
          <div>
            <Reveal>
              <SectionTag index="02" title="Services" />
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-8 max-w-xl text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
                Full-spectrum capability, one consultancy.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.15}>
            <p className="max-w-sm text-[15px] leading-relaxed text-fog">
              Six core disciplines, coordinated by one team — so your drawings, budgets and site
              work never fall out of sync.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.1} className="mt-14 md:mt-16">
          <div className="grid gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((service) => {
              const Icon = ICONS[service.icon] ?? Building2;
              return (
                <a
                  key={service.id}
                  href="#contact"
                  className="group relative flex flex-col overflow-hidden bg-ink p-7 transition-colors duration-500 hover:bg-coal md:p-9"
                >
                  <div className="flex items-start justify-between">
                    <Icon
                      strokeWidth={1.5}
                      className="size-7 text-fog transition-colors duration-500 group-hover:text-signal"
                    />
                    <span className="font-mono text-xs text-fog/60">{service.id}</span>
                  </div>
                  <h3 className="mt-10 max-w-[18ch] text-xl font-semibold tracking-tight text-bone md:mt-14 md:text-[22px]">
                    {service.title}
                  </h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-fog">{service.text}</p>
                  <span className="mt-8 flex items-center gap-2 font-mono text-[10px] tracking-[0.24em] text-signal uppercase opacity-0 transition-all duration-500 group-hover:opacity-100">
                    Request this service
                    <ArrowUpRight className="size-3.5" />
                  </span>
                  {/* amber underline that sweeps in on hover */}
                  <span className="absolute bottom-0 left-0 h-0.5 w-0 bg-signal transition-all duration-500 group-hover:w-full" />
                </a>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
