import { Diamond } from "lucide-react";

// The scrolling amber ticker band. Items are duplicated so the
// translateX(-50%) animation loops forever without a visible seam.
const ITEMS = [
  "Civil Engineering",
  "Structural Design",
  "Architectural Planning",
  "Construction Supervision",
  "Project Management",
  "Land Surveying",
  "Permits & Approvals",
  "Electrical & Mechanical",
];

export function Marquee() {
  return (
    <section aria-hidden className="relative z-10 -my-6 w-[110%] -rotate-[1.4deg] -ml-[5%]">
      <div className="border-y border-ink/20 bg-signal py-3.5 md:py-4">
        <div className="flex w-max animate-marquee items-center gap-10 whitespace-nowrap pr-10">
          {[...ITEMS, ...ITEMS].map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-10 font-mono text-[11px] font-semibold tracking-[0.3em] text-ink uppercase md:text-[13px]"
            >
              {item}
              <Diamond className="size-2.5 fill-ink/60 text-ink/60" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
