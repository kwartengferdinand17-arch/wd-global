import Image from "next/image";
import { Plus } from "lucide-react";
import { IMAGES, SITE } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";
import { Stats } from "./stats";

// "01 / THE PRACTICE" — who the company is + the animated stats band.
export function About() {
  return (
    <section id="practice" className="relative scroll-mt-20 py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <SectionTag index="01" title="The Practice" />
        </Reveal>

        <div className="mt-10 grid gap-14 lg:grid-cols-12 lg:gap-12">
          {/* statement + copy */}
          <div className="lg:col-span-7">
            <Reveal>
              <h2 className="max-w-2xl text-3xl leading-[1.1] font-semibold tracking-[-0.01em] text-balance md:text-[3.4rem] md:leading-[1.05]">
                We turn land, drawings and budgets into{" "}
                <span className="text-signal">structures that stand.</span>
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-xl leading-relaxed text-fog md:text-lg">
                From our base at {SITE.location} in Kumasi, {SITE.shortName} Consult Limited delivers
                end-to-end engineering support for residential, commercial and institutional
                projects across Ghana — drawings, approvals, costing and site supervision under one
                roof.
              </p>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-fog/80">
                Every engagement is led by qualified engineers and documented to the last bolt — so
                regulators sign off faster, contractors build right the first time, and you always
                know exactly where your money is going.
              </p>
            </Reveal>

            <Reveal delay={0.22}>
              <div className="mt-10 flex flex-wrap gap-3 font-mono text-[10px] tracking-[0.2em] uppercase">
                {["Residential", "Commercial", "Industrial", "Roads & Drainage"].map((tag) => (
                  <span key={tag} className="border border-line px-3.5 py-2 text-fog">
                    {tag}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>

          {/* framed photograph */}
          <div className="lg:col-span-5">
            <Reveal delay={0.15} className="relative">
              <div className="relative overflow-hidden border border-line">
                <Image
                  src={IMAGES.about}
                  alt="WD Global engineers reviewing drawings on site"
                  width={940}
                  height={650}
                  className="aspect-[4/3] w-full object-cover grayscale-[28%] contrast-[1.05] transition-transform duration-700 hover:scale-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
                <Plus className="absolute top-2.5 left-2.5 size-4 text-signal/80" />
                <Plus className="absolute top-2.5 right-2.5 size-4 text-signal/80" />
                <figcaption className="absolute bottom-3.5 left-3.5 border border-line bg-ink/70 px-3 py-1.5 font-mono text-[9px] tracking-[0.24em] text-fog uppercase backdrop-blur">
                  Fig. 02 — Drawing review on site
                </figcaption>
              </div>
              {/* offset accent plate */}
              <div className="absolute -right-3 -bottom-3 -z-10 h-full w-full border border-signal/30" />
              <div className="absolute right-5 -bottom-5 border border-line bg-coal px-4 py-3">
                <p className="font-mono text-[9px] tracking-[0.24em] text-fog uppercase">Based in</p>
                <p className="mt-0.5 text-sm font-semibold text-bone">Kwadaso · Kumasi, Ghana</p>
              </div>
            </Reveal>
          </div>
        </div>

        {/* animated track-record band */}
        <Reveal delay={0.1} className="mt-24 md:mt-32">
          <Stats />
        </Reveal>
      </div>
    </section>
  );
}
