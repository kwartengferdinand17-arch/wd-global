"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUp, MessageCircle } from "lucide-react";
import { SITE } from "@/lib/site";

// The WhatsApp chat link — opens WhatsApp with a pre-typed message to the company.
const WHATSAPP_URL = `https://wa.me/${SITE.phoneRaw.replace("+", "")}?text=${encodeURIComponent(
  "Hello WD Global Engineering, I would like to discuss a project.",
)}`;

// Two floating buttons in the bottom-right corner on every screen:
// a WhatsApp chat button (always) + a back-to-top button (after scrolling).
export function FloatingActions() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed right-5 bottom-5 z-40 flex flex-col items-end gap-3 md:right-6 md:bottom-6">
      {/* back to top — only after scrolling down */}
      <AnimatePresence>
        {showTop && (
          <motion.a
            key="top"
            href="#top"
            aria-label="Back to top"
            initial={{ opacity: 0, y: 12, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.8 }}
            transition={{ duration: 0.3 }}
            className="grid size-11 place-items-center border border-line bg-ink/85 text-bone backdrop-blur transition-colors hover:border-signal/70 hover:text-signal"
          >
            <ArrowUp className="size-4.5" />
          </motion.a>
        )}
      </AnimatePresence>

      {/* WhatsApp chat */}
      <motion.a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with us on WhatsApp"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.1, type: "spring", stiffness: 260, damping: 18 }}
        className="group relative grid size-14 place-items-center rounded-full bg-[#22c55e] text-white shadow-[0_12px_32px_rgba(34,197,94,0.35)] transition-transform duration-300 hover:scale-105"
      >
        <span className="absolute inset-0 animate-ping rounded-full bg-[#22c55e]/30" />
        <MessageCircle className="relative size-6" />
        <span className="pointer-events-none absolute right-full mr-3 hidden border border-line bg-ink px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] whitespace-nowrap text-bone uppercase opacity-0 transition-opacity duration-300 group-hover:opacity-100 md:block">
          Chat on WhatsApp
        </span>
      </motion.a>
    </div>
  );
}
