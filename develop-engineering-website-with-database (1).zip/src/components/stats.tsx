"use client";

import { useEffect, useRef } from "react";
import { animate, useInView } from "framer-motion";
import { STATS } from "@/lib/site";

// A number that counts up from 0 the first time it scrolls into view.
function CountUp({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  useEffect(() => {
    if (!inView || !ref.current) return;
    const controls = animate(0, value, {
      duration: 1.8,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => {
        if (ref.current) ref.current.textContent = Math.round(v).toString();
      },
    });
    return () => controls.stop();
  }, [inView, value]);

  return <span ref={ref}>0</span>;
}

// The "track record" band: 120+ projects, 40+ clients…
export function Stats() {
  return (
    <dl className="grid grid-cols-2 border border-line lg:grid-cols-4">
      {STATS.map((stat, i) => (
        <div
          key={stat.label}
          className={`group px-6 py-8 transition-colors duration-500 hover:bg-coal md:px-8 md:py-10 ${
            i > 0 ? "border-l border-line" : ""
          } ${i > 1 ? "max-lg:border-t max-lg:border-line" : ""} ${i === 2 ? "max-lg:border-l-0" : ""}`}
        >
          <dt className="order-2 mt-4 font-mono text-[10px] tracking-[0.24em] text-fog uppercase md:text-[11px]">
            {stat.label}
          </dt>
          <dd className="text-4xl font-semibold tracking-tight text-bone md:text-5xl">
            <CountUp value={stat.value} />
            <span className="text-signal">{stat.suffix}</span>
          </dd>
        </div>
      ))}
    </dl>
  );
}
