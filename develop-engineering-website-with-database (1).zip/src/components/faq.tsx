"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Phone, Plus } from "lucide-react";
import { FAQS, SITE } from "@/lib/site";
import { SectionTag } from "./section-tag";

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

// "07 / FAQ" — an accordion: click a question, its answer unfolds smoothly.
// useState remembers WHICH question is open (a number, or null for none).
export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section
      id="faq"
      className="blueprint-light scroll-mt-20 border-t border-paperline bg-paper text-ink"
    >
      <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 md:px-8 md:py-32 lg:grid-cols-12">
        {/* sticky left column */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-32">
            <SectionTag index="07" title="FAQ" tone="light" />
            <h2 className="mt-8 text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
              Questions, answered<span className="text-amberdeep">.</span>
            </h2>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-ink/60">
              The things homeowners and developers ask us most. If your question is not here, call
              us — an engineer will pick up, not a bot.
            </p>

            {/* "prefer to talk" card */}
            <div className="mt-10 flex items-center gap-4 border border-paperline bg-white p-5">
              <span className="grid size-12 shrink-0 place-items-center bg-signal text-ink">
                <Phone className="size-5" strokeWidth={1.5} />
              </span>
              <div>
                <p className="font-mono text-[10px] tracking-[0.24em] text-ink/50 uppercase">
                  Prefer to talk?
                </p>
                <a
                  href={`tel:${SITE.phoneRaw}`}
                  className="mt-0.5 block text-lg font-semibold tracking-tight transition-colors hover:text-amberdeep"
                >
                  {SITE.phoneLocal}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* the accordion list */}
        <div className="lg:col-span-7">
          <ul>
            {FAQS.map((item, i) => {
              const isOpen = open === i;
              return (
                <li key={item.q} className="border-b border-paperline first:border-t">
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    className="group flex w-full items-center justify-between gap-6 py-6 text-left md:py-7"
                  >
                    <span className="text-base font-semibold tracking-tight transition-colors group-hover:text-amberdeep md:text-lg">
                      {item.q}
                    </span>
                    <span
                      className={`grid size-8 shrink-0 place-items-center border transition-all duration-400 ${
                        isOpen
                          ? "rotate-45 border-ink bg-ink text-paper"
                          : "border-paperline text-ink/60 group-hover:border-ink/40"
                      }`}
                    >
                      <Plus className="size-4" />
                    </span>
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.45, ease: EASE }}
                        className="overflow-hidden"
                      >
                        <p className="max-w-2xl pb-7 text-[15px] leading-relaxed text-ink/65">
                          {item.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
