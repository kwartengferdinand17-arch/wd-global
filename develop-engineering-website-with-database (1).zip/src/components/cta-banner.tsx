import Image from "next/image";
import { ArrowUpRight, MessageCircle, Phone } from "lucide-react";
import { EXTRA_IMAGES, SITE } from "@/lib/site";
import { Reveal } from "./reveal";

// The invited WhatsApp chat link (opens WhatsApp with a pre-typed message).
const WHATSAPP_URL = `https://wa.me/${SITE.phoneRaw.replace("+", "")}?text=${encodeURIComponent(
  "Hello WD Global Engineering, I would like to discuss a project.",
)}`;

// The big photographic call-to-action just before the contact section.
export function CtaBanner() {
  return (
    <section className="relative overflow-hidden">
      <div className="relative flex min-h-[560px] items-center md:h-[70vh]">
        {/* background photo + dark overlay */}
        <Image
          src={EXTRA_IMAGES.banner}
          alt="Engineers reviewing plans inside an unfinished building"
          fill
          sizes="100vw"
          className="object-cover grayscale-[25%]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/75 to-ink/25" />

        {/* content */}
        <div className="relative mx-auto w-full max-w-7xl px-5 py-20 md:px-8">
          <Reveal>
            <p className="flex items-center gap-2.5 font-mono text-[10px] tracking-[0.3em] text-signal uppercase md:text-[11px]">
              <span className="size-1.5 animate-pulse-dot rounded-full bg-signal" />
              Ready when you are
            </p>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-6 max-w-3xl text-4xl leading-[1.02] font-semibold tracking-[-0.02em] text-balance md:text-6xl lg:text-7xl">
              Have the land. Bring the vision.{" "}
              <span className="text-outline">We engineer the rest.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <a
                href={`tel:${SITE.phoneRaw}`}
                className="group inline-flex items-center gap-2 bg-signal px-7 py-4 font-mono text-[11px] font-semibold tracking-[0.16em] text-ink uppercase transition-colors duration-300 hover:bg-bone"
              >
                <Phone className="size-4" />
                Call {SITE.phoneLocal}
              </a>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-2 border border-bone/25 px-7 py-4 font-mono text-[11px] tracking-[0.16em] text-bone uppercase transition-colors duration-300 hover:border-signal hover:text-signal"
              >
                <MessageCircle className="size-4" />
                WhatsApp us
                <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          </Reveal>
          <Reveal delay={0.22}>
            <p className="mt-10 font-mono text-[10px] tracking-[0.24em] text-bone/50 uppercase">
              {SITE.location} · {SITE.city}
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
