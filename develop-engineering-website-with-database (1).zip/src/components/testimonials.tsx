import Image from "next/image";
import { Quote, Star } from "lucide-react";
import { TESTIMONIALS } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

// "06 / TESTIMONIALS" — client reviews on the warm "paper" background.
export function Testimonials() {
  return (
    <section id="testimonials" className="blueprint-light scroll-mt-20 bg-paper text-ink">
      <div className="mx-auto max-w-7xl px-5 py-24 md:px-8 md:py-32">
        {/* header */}
        <div className="flex flex-wrap items-end justify-between gap-8">
          <div>
            <Reveal>
              <SectionTag index="06" title="Testimonials" tone="light" />
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-8 max-w-xl text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
                Clients rate the work<span className="text-amberdeep">.</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.15}>
            <div className="flex items-center gap-3">
              <span className="flex gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-amberdeep text-amberdeep" />
                ))}
              </span>
              <span className="font-mono text-[10px] tracking-[0.2em] text-ink/55 uppercase">
                5.0 average · 60+ reviews
              </span>
            </div>
          </Reveal>
        </div>

        {/* review cards */}
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.08} className="h-full">
              <figure className="flex h-full flex-col border border-paperline bg-white p-7 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_24px_48px_rgba(16,18,20,0.12)] md:p-8">
                <div className="flex items-center justify-between">
                  <Quote className="size-6 fill-amberdeep/20 text-amberdeep" />
                  <span className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, s) => (
                      <Star key={s} className="size-3.5 fill-amberdeep text-amberdeep" />
                    ))}
                  </span>
                </div>
                <blockquote className="mt-6 flex-1 text-[15px] leading-relaxed text-ink/75">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <figcaption className="mt-8 flex items-center gap-3.5 border-t border-paperline pt-6">
                  <span className="relative block size-11 shrink-0 overflow-hidden rounded-full border border-paperline">
                    <Image
                      src={t.avatar}
                      alt={`Portrait of ${t.name}`}
                      width={88}
                      height={88}
                      className="h-full w-full object-cover"
                    />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">{t.name}</span>
                    <span className="mt-0.5 block font-mono text-[10px] tracking-[0.16em] text-ink/50 uppercase">
                      {t.role}
                    </span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
