"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useScroll } from "framer-motion";
import { ArrowUpRight, Mail, Menu, Phone, X } from "lucide-react";
import { NAV_LINKS, SITE } from "@/lib/site";

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

// Fixed top navigation — shrinks into a blurred bar after scrolling,
// and opens a full-screen menu on phones.
export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  // tracks how far the page is scrolled — drives the amber progress bar
  const { scrollYProgress } = useScroll();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // stop page scrolling while the mobile menu is open
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, ease: EASE, delay: 0.15 }}
        className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
          scrolled ? "border-b border-line bg-ink/85 backdrop-blur-xl" : "border-b border-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:h-20 md:px-8">
          {/* Logo */}
          <a href="#top" className="group flex items-center gap-3">
            <span className="grid size-9 place-items-center border border-signal/70 font-mono text-sm font-semibold text-signal transition-colors duration-300 group-hover:bg-signal group-hover:text-ink">
              {SITE.monogram}
            </span>
            <span className="hidden leading-tight sm:block">
              <span className="block text-[13px] font-semibold tracking-[0.08em]">WD GLOBAL</span>
              <span className="block font-mono text-[9px] uppercase tracking-[0.28em] text-fog">
                Engineering Consult Ltd
              </span>
            </span>
          </a>

          {/* Desktop links */}
          <nav className="hidden items-center gap-8 lg:flex">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="group relative font-mono text-[11px] tracking-[0.22em] text-fog uppercase transition-colors hover:text-bone"
              >
                {link.label}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-signal transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right side: phone + CTA (desktop) / menu button (mobile) */}
          <div className="flex items-center gap-3">
            <a
              href={`tel:${SITE.phoneRaw}`}
              className="hidden items-center gap-2 border border-line px-3.5 py-2 font-mono text-[11px] tracking-[0.14em] text-bone transition-colors hover:border-signal/60 hover:text-signal md:flex"
            >
              <Phone className="size-3.5 text-signal" />
              {SITE.phoneLocal}
            </a>
            <a
              href="#contact"
              className="group hidden items-center gap-1.5 bg-signal px-4 py-2 font-mono text-[11px] font-semibold tracking-[0.14em] text-ink uppercase transition-colors hover:bg-bone md:flex"
            >
              Book a survey
              <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <button
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              className="grid size-10 place-items-center border border-line text-bone lg:hidden"
            >
              <Menu className="size-5" />
            </button>
          </div>
        </div>

        {/* amber scroll-progress bar under the nav */}
        <motion.div
          style={{ scaleX: scrollYProgress }}
          className="absolute inset-x-0 bottom-0 h-0.5 origin-left bg-signal"
        />
      </motion.header>

      {/* Full-screen mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="fixed inset-0 z-[60] flex flex-col bg-ink blueprint"
          >
            <div className="flex h-16 items-center justify-between px-5">
              <span className="font-mono text-[11px] tracking-[0.3em] text-fog uppercase">Menu</span>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="grid size-10 place-items-center border border-line text-bone"
              >
                <X className="size-5" />
              </button>
            </div>
            <nav className="flex flex-1 flex-col justify-center gap-2 px-6 no-scrollbar overflow-y-auto">
              {NAV_LINKS.map((link, i) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  initial={{ opacity: 0, y: 26 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.08 + i * 0.07, ease: EASE }}
                  className="group flex items-baseline gap-4 py-3"
                >
                  <span className="font-mono text-xs text-signal">0{i + 1}</span>
                  <span className="text-4xl font-semibold tracking-tight text-bone transition-colors group-hover:text-signal">
                    {link.label}
                  </span>
                </motion.a>
              ))}
            </nav>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.45 }}
              className="space-y-3 border-t border-line px-6 py-6"
            >
              <a href={`tel:${SITE.phoneRaw}`} className="flex items-center gap-3 font-mono text-sm text-bone">
                <Phone className="size-4 text-signal" /> {SITE.phoneLocal}
              </a>
              <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 font-mono text-xs text-fog">
                <Mail className="size-4 text-signal" /> {SITE.email}
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
