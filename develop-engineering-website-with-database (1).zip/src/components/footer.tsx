import { ArrowUp, Inbox, Mail, MapPin, Phone } from "lucide-react";
import { CREDITS, NAV_LINKS, SERVICES, SITE } from "@/lib/site";

// Footer with the giant outlined wordmark, sitemap and contact details.
export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-line">
      {/* giant wordmark */}
      <div className="overflow-hidden border-b border-line">
        <div className="mx-auto max-w-7xl px-5 pt-12 md:px-8 md:pt-16">
          <h2 className="text-outline-faint leading-[0.95] font-semibold tracking-[-0.03em] select-none">
            <span className="block text-[12.5vw] whitespace-nowrap lg:text-[9.5vw]">
              WD GLOBAL<span style={{ WebkitTextStroke: "0px", color: "var(--color-signal)" }}>.</span>
            </span>
          </h2>
          <p className="pb-8 font-mono text-[10px] tracking-[0.3em] text-fog/70 uppercase md:pb-10">
            Engineering precision for the built environment
          </p>
        </div>
      </div>

      {/* link columns */}
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-14 md:grid-cols-2 md:px-8 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center border border-signal/70 font-mono text-sm font-semibold text-signal">
              {SITE.monogram}
            </span>
            <span className="leading-tight">
              <span className="block text-[13px] font-semibold tracking-[0.08em]">WD GLOBAL</span>
              <span className="block font-mono text-[9px] tracking-[0.28em] text-fog uppercase">
                Engineering Consult Ltd
              </span>
            </span>
          </div>
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-fog">
            Civil, structural and construction consultancy for homeowners, developers and
            institutions across Ghana.
          </p>
          <p className="mt-5 inline-flex items-center gap-2.5 border border-line px-3.5 py-2 font-mono text-[10px] tracking-[0.2em] text-fog uppercase">
            <span className="size-1.5 animate-pulse-dot rounded-full bg-signal" />
            Open for new projects
          </p>
        </div>

        <div>
          <p className="font-mono text-[10px] tracking-[0.26em] text-fog uppercase">Contact</p>
          <ul className="mt-5 space-y-4 text-sm">
            <li>
              <a
                href={`tel:${SITE.phoneRaw}`}
                className="flex items-center gap-3 text-bone transition-colors hover:text-signal"
              >
                <Phone className="size-4 text-signal" /> {SITE.phoneLocal}
              </a>
            </li>
            <li>
              <a
                href={`mailto:${SITE.email}`}
                className="flex items-center gap-3 break-all text-bone transition-colors hover:text-signal"
              >
                <Mail className="size-4 shrink-0 text-signal" /> {SITE.email}
              </a>
            </li>
            <li className="flex items-start gap-3 text-fog">
              <MapPin className="mt-0.5 size-4 shrink-0 text-signal" />
              <span>
                {SITE.location}
                <br />
                {SITE.city}
              </span>
            </li>
          </ul>
        </div>

        <div>
          <p className="font-mono text-[10px] tracking-[0.26em] text-fog uppercase">Navigate</p>
          <ul className="mt-5 space-y-3.5">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-sm text-fog transition-colors hover:text-bone"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-mono text-[10px] tracking-[0.26em] text-fog uppercase">Services</p>
          <ul className="mt-5 space-y-3.5">
            {SERVICES.map((service) => (
              <li key={service.id} className="font-mono text-xs leading-relaxed text-fog">
                <span className="text-signal/60">{service.id}</span> — {service.title}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* bottom bar */}
      <div className="border-t border-line">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-5 font-mono text-[10px] tracking-[0.16em] text-fog/70 uppercase md:px-8">
          <p>© {year} {SITE.name}. All rights reserved.</p>
          <p className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span>Need a website? Contact the developer:</span>
            <a
              href={`mailto:${CREDITS.email}`}
              className="text-fog underline decoration-line underline-offset-4 transition-colors normal-case hover:text-signal"
            >
              {CREDITS.email}
            </a>
            <span className="text-fog/40">·</span>
            <a href={`tel:${CREDITS.phoneRaw}`} className="text-fog transition-colors hover:text-signal">
              {CREDITS.phoneLocal}
            </a>
          </p>
          <div className="flex items-center gap-6">
            <a href="/admin" className="flex items-center gap-2 transition-colors hover:text-signal">
              <Inbox className="size-3.5" /> Enquiries inbox
            </a>
            <a
              href="#top"
              className="flex items-center gap-2 transition-colors hover:text-signal"
            >
              Back to top <ArrowUp className="size-3.5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
