"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowDown, ArrowUpRight, Mail, MapPin, Phone, Plus } from "lucide-react";
import type { ReactNode } from "react";
import { IMAGES, SITE } from "@/lib/site";

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

// One oversized headline line that slides up from behind an overflow mask.
function HeadlineLine({
  children,
  delay,
  className,
}: {
  children: ReactNode;
  delay: number;
  className?: string;
}) {
  return (
    <span className="block overflow-hidden pb-[0.06em]">
      <motion.span
        className={`block ${className ?? ""}`}
        initial={{ y: "110%" }}
        animate={{ y: "0%" }}
        transition={{ duration: 1.1, delay, ease: EASE }}
      >
        {children}
      </motion.span>
    </span>
  );
}

export function Hero() {
  return (
    <section id="top" className="blueprint relative overflow-hidden">
      {/* soft amber glow + fade to black at the bottom */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_55%_at_68%_6%,rgba(255,178,0,0.07),transparent_62%)]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-44 bg-gradient-to-b from-transparent to-ink" />

      <div className="relative mx-auto max-w-7xl px-5 pt-32 pb-16 md:px-8 md:pt-44">
        {/* top meta row */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35, ease: EASE }}
          className="mb-8 flex flex-wrap items-center justify-between gap-4 font-mono text-[10px] tracking-[0.26em] text-fog uppercase md:mb-12 md:text-[11px]"
        >
          <span className="flex items-center gap-2.5">
            <span className="size-1.5 animate-pulse-dot rounded-full bg-signal" />
            Available for new projects
          </span>
          <span className="hidden tracking-[0.26em] md:block">
            Kumasi, Ghana — 6.67° N, 1.65° W
          </span>
        </motion.div>

        {/* headline */}
        <h1 className="text-[clamp(3.1rem,10.5vw,8.75rem)] leading-[0.94] font-semibold tracking-[-0.025em]">
          <HeadlineLine delay={0.15}>ENGINEERING</HeadlineLine>
          <HeadlineLine delay={0.28} className="text-outline">
            PRECISION<span style={{ WebkitTextStroke: "0px", color: "var(--color-signal)" }}>.</span>
          </HeadlineLine>
        </h1>

        {/* content grid */}
        <div className="mt-12 grid gap-12 md:mt-16 md:grid-cols-12">
          {/* left — pitch + actions */}
          <motion.div
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.55, ease: EASE }}
            className="flex flex-col justify-between gap-10 md:col-span-5"
          >
            <p className="max-w-md text-[15px] leading-relaxed text-fog md:text-base">
              {SITE.name} helps homeowners, developers and institutions plan, design and build —
              from structural drawings to final handover.{" "}
              <span className="text-bone">Safely. On budget. On time.</span>
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <a
                href="#contact"
                className="group inline-flex items-center gap-2 bg-signal px-6 py-4 font-mono text-[11px] font-semibold tracking-[0.16em] text-ink uppercase transition-colors duration-300 hover:bg-bone"
              >
                Book a consultation
                <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
              <a
                href="#services"
                className="inline-flex items-center gap-2 border border-line px-6 py-4 font-mono text-[11px] tracking-[0.16em] text-bone uppercase transition-colors duration-300 hover:border-signal/60 hover:text-signal"
              >
                Explore services
                <ArrowDown className="size-4" />
              </a>
            </div>

            <div className="hidden items-center gap-5 font-mono text-[10px] tracking-[0.2em] text-fog uppercase md:flex">
              <span className="flex items-center gap-2">
                <Phone className="size-3.5 text-signal" /> {SITE.phoneLocal}
              </span>
              <span className="h-3 w-px bg-line" />
              <span className="flex items-center gap-2">
                <MapPin className="size-3.5 text-signal" /> Kwadaso, Kumasi
              </span>
            </div>
          </motion.div>

          {/* right — framed site photograph */}
          <motion.figure
            initial={{ opacity: 0, y: 44, scale: 1.03 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1.1, delay: 0.45, ease: EASE }}
            className="relative md:col-span-7"
          >
            <div className="relative overflow-hidden border border-line">
              <Image
                src={IMAGES.hero}
                alt="Tower cranes over an active construction site at sunset"
                width={1200}
                height={750}
                priority
                className="aspect-[16/10] w-full object-cover grayscale-[28%] contrast-[1.05]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-ink/10" />
              <Plus className="absolute top-2.5 left-2.5 size-4 text-signal/80" />
              <Plus className="absolute top-2.5 right-2.5 size-4 text-signal/80" />
              <Plus className="absolute bottom-2.5 left-2.5 size-4 text-signal/80" />
              <Plus className="absolute right-2.5 bottom-2.5 size-4 text-signal/80" />
              <figcaption className="absolute bottom-3.5 left-3.5 border border-line bg-ink/70 px-3 py-1.5 font-mono text-[9px] tracking-[0.24em] text-fog uppercase backdrop-blur">
                Fig. 01 — Active site, Kumasi
              </figcaption>
              <span className="absolute top-3.5 right-3.5 border border-line bg-ink/70 px-3 py-1.5 font-mono text-[9px] tracking-[0.24em] text-signal uppercase backdrop-blur">
                WD-G01
              </span>
            </div>

            {/* rotating circular badge */}
            <div className="absolute -bottom-9 -left-9 hidden size-28 place-items-center md:grid">
              <svg viewBox="0 0 100 100" className="size-full animate-spin-slower">
                <defs>
                  <path id="badge-circle" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0" />
                </defs>
                <text className="fill-fog font-mono text-[8px] uppercase" style={{ letterSpacing: "2.6px" }}>
                  <textPath href="#badge-circle">WD GLOBAL · ENGINEERING CONSULT · KUMASI ·</textPath>
                </text>
              </svg>
              <ArrowDown className="absolute size-4 text-signal" />
            </div>
          </motion.figure>
        </div>

        {/* bottom contact strip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.85 }}
          className="mt-16 grid grid-cols-1 gap-px border border-line bg-line sm:grid-cols-3 md:mt-24"
        >
          <a
            href={`tel:${SITE.phoneRaw}`}
            className="group flex items-center gap-3 bg-ink px-5 py-4 font-mono text-[11px] tracking-[0.14em] text-fog uppercase transition-colors hover:text-bone"
          >
            <Phone className="size-4 shrink-0 text-signal" />
            <span>Call — {SITE.phoneLocal}</span>
            <ArrowUpRight className="ml-auto size-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </a>
          <a
            href={`mailto:${SITE.email}`}
            className="group flex items-center gap-3 bg-ink px-5 py-4 font-mono text-[11px] tracking-[0.14em] text-fog uppercase transition-colors hover:text-bone"
          >
            <Mail className="size-4 shrink-0 text-signal" />
            <span className="truncate">{SITE.email}</span>
            <ArrowUpRight className="ml-auto size-3.5 shrink-0 opacity-0 transition-opacity group-hover:opacity-100" />
          </a>
          <div className="flex items-center gap-3 bg-ink px-5 py-4 font-mono text-[11px] tracking-[0.14em] text-fog uppercase">
            <MapPin className="size-4 shrink-0 text-signal" />
            <span>Estate Kwadaso · Nr. Police Hospital</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
