"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

// Butter-smooth ease-out curve used across the whole site.
const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

// Reveal = a wrapper that fades + slides its children up the first time
// they scroll into view. Used by almost every section.
export function Reveal({
  children,
  className,
  delay = 0,
  y = 32,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  y?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.9, delay, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}
