import { ArrowUpRight } from "lucide-react";
import { PROCESS } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

// "03 / PROCESS" — how an engagement runs, step by step.
export function Process() {
  return (
    <section id="process" className="scroll-mt-20 border-t border-line py-24 md:py-36">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-12">
        {/* sticky intro column */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-32">
            <Reveal>
              <SectionTag index="04" title="Process" />
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-8 text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
                From first call to final handover.
              </h2>
            </Reveal>
            <Reveal delay={0.15}>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-fog">
                A structured, transparent way of working. You approve every stage before we move —
                no surprise invoices, no silent weeks.
              </p>
            </Reveal>
            <Reveal delay={0.2}>
              <a
                href="#contact"
                className="group mt-8 inline-flex items-center gap-2 font-mono text-[11px] tracking-[0.2em] text-signal uppercase"
              >
                Start your project
                <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </Reveal>
          </div>
        </div>

        {/* steps */}
        <div className="lg:col-span-7">
          {PROCESS.map((step, i) => (
            <Reveal key={step.id} delay={i * 0.06}>
              <div className="group grid grid-cols-[auto_1fr] gap-5 border-t border-line py-8 transition-colors duration-500 last:border-b hover:bg-coal/40 md:gap-8 md:py-10">
                <span className="pt-1 font-mono text-xs text-signal">{step.id}</span>
                <div>
                  <h3 className="text-xl font-semibold tracking-tight text-bone transition-transform duration-500 group-hover:translate-x-1.5 md:text-2xl">
                    {step.title}
                  </h3>
                  <p className="mt-2.5 max-w-lg text-sm leading-relaxed text-fog md:text-[15px]">
                    {step.text}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
