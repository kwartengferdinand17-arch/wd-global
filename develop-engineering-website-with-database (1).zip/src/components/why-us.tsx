import Image from "next/image";
import { BadgeCheck, Plus } from "lucide-react";
import { CERTS, EXTRA_IMAGES, WHY_POINTS } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

// "03 / WHY CHOOSE WD" — team photograph + the five promises + trust badges.
export function WhyUs() {
  return (
    <section id="why-us" className="relative scroll-mt-20 overflow-hidden border-t border-line py-24 md:py-36">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(55%_45%_at_85%_90%,rgba(255,178,0,0.05),transparent_60%)]" />

      <div className="relative mx-auto grid max-w-7xl gap-16 px-5 md:px-8 lg:grid-cols-12 lg:gap-14">
        {/* left — team photograph */}
        <div className="lg:col-span-5">
          <Reveal className="relative lg:sticky lg:top-32">
            <div className="relative overflow-hidden border border-line">
              <Image
                src={EXTRA_IMAGES.team}
                alt="WD Global engineering team reviewing construction drawings"
                width={1200}
                height={800}
                className="aspect-[4/3] w-full object-cover grayscale-[30%] contrast-[1.05] transition-all duration-700 hover:scale-[1.03] hover:grayscale-0"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
              <Plus className="absolute top-2.5 left-2.5 size-4 text-signal/80" />
              <Plus className="absolute top-2.5 right-2.5 size-4 text-signal/80" />
              <figcaption className="absolute bottom-3.5 left-3.5 border border-line bg-ink/70 px-3 py-1.5 font-mono text-[9px] tracking-[0.24em] text-fog uppercase backdrop-blur">
                Fig. 03 — The engineering team
              </figcaption>
            </div>
            {/* offset accent plate + promise chip */}
            <div className="absolute -right-3 -bottom-3 -z-10 h-full w-full border border-signal/30" />
            <div className="absolute -bottom-5 left-5 border border-line bg-coal px-4 py-3">
              <p className="font-mono text-[9px] tracking-[0.24em] text-fog uppercase">Response promise</p>
              <p className="mt-0.5 text-sm font-semibold text-bone">Same business day</p>
            </div>
          </Reveal>
        </div>

        {/* right — the five promises */}
        <div className="lg:col-span-7">
          <Reveal>
            <SectionTag index="03" title="Why Choose WD" />
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-8 max-w-xl text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
              Built on five promises<span className="text-signal">.</span>
            </h2>
          </Reveal>

          <div className="mt-12 space-y-8">
            {WHY_POINTS.map((point, i) => (
              <Reveal key={point.title} delay={0.05 + i * 0.05}>
                <div className="group grid grid-cols-[auto_1fr] items-start gap-5">
                  <span className="grid size-10 place-items-center border border-line text-signal transition-colors duration-500 group-hover:border-signal/60">
                    <BadgeCheck className="size-4.5" strokeWidth={1.5} />
                  </span>
                  <div>
                    <h3 className="text-lg font-semibold tracking-tight text-bone md:text-xl">
                      {point.title}
                    </h3>
                    <p className="mt-1.5 max-w-lg text-sm leading-relaxed text-fog md:text-[15px]">
                      {point.text}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* trust badges */}
          <Reveal delay={0.2}>
            <div className="mt-14 flex flex-wrap gap-3">
              {CERTS.map((cert) => (
                <span
                  key={cert}
                  className="border border-line px-4 py-2.5 font-mono text-[10px] tracking-[0.22em] text-fog uppercase transition-colors duration-300 hover:border-signal/60 hover:text-bone"
                >
                  {cert}
                </span>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
