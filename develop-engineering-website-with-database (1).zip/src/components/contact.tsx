"use client";

import { useState, type ChangeEvent, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUpRight,
  CheckCircle2,
  ChevronDown,
  Clock,
  Loader2,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
} from "lucide-react";
import { SERVICES, SITE } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

// ── the data the visitor types into the form ──────────────────────────────
type FormState = {
  name: string;
  email: string;
  phone: string;
  service: string;
  preferredDate: string;
  message: string;
};

const EMPTY: FormState = {
  name: "",
  email: "",
  phone: "",
  service: "",
  preferredDate: "",
  message: "",
};

// shared styling for every input / select / textarea
const inputCls =
  "w-full border-b border-line bg-transparent py-3 text-[15px] text-bone placeholder:text-fog/40 outline-none transition-colors duration-300 focus:border-signal";
const labelCls = "mb-1 block font-mono text-[10px] uppercase tracking-[0.22em] text-fog";

// contact channels shown in the left column
const CHANNELS = [
  { icon: Phone, label: "Call / WhatsApp", value: SITE.phoneLocal, href: `tel:${SITE.phoneRaw}` },
  { icon: Mail, label: "Email", value: SITE.email, href: `mailto:${SITE.email}` },
  { icon: MapPin, label: "Visit the office", value: `${SITE.location}, ${SITE.city}` },
  { icon: Clock, label: "Working hours", value: SITE.hours },
];

// "05 / CONTACT" — booking form that saves into the PostgreSQL database.
export function Contact() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [error, setError] = useState<string | null>(null);
  const [refId, setRefId] = useState<number | null>(null);

  // one helper updates any field: <input onChange={update("name")} />
  const update =
    (key: keyof FormState) =>
    (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    setError(null);
    try {
      // send the data to our API route, which stores it in the database
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error ?? "Could not send your enquiry.");
      setRefId(data.id);
      setStatus("success");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setStatus("error");
    }
  }

  function resetForm() {
    setForm(EMPTY);
    setStatus("idle");
    setRefId(null);
  }

  return (
    <section
      id="contact"
      className="relative scroll-mt-20 overflow-hidden border-t border-line py-24 md:py-36"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_15%_100%,rgba(255,178,0,0.05),transparent_60%)]" />

      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-[1fr_1.15fr] lg:gap-16">
        {/* ── left column: invitation + contact channels ─────────────────── */}
        <div>
          <Reveal>
            <SectionTag index="08" title="Contact" />
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-8 text-3xl leading-[1.08] font-semibold tracking-[-0.01em] md:text-5xl">
              Book a site visit or consultation.
            </h2>
          </Reveal>
          <Reveal delay={0.15}>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-fog">
              Tell us about your project — a plot you have bought, a building that needs inspection,
              a design you want priced. Fill the form and our engineers will respond{" "}
              <span className="text-bone">within one business day</span>.
            </p>
          </Reveal>

          <Reveal delay={0.2}>
            <ul className="mt-10 space-y-5">
              {CHANNELS.map((channel) => {
                const Icon = channel.icon;
                const content = (
                  <>
                    <span className="grid size-11 shrink-0 place-items-center border border-line text-signal transition-colors duration-300 group-hover:border-signal/60">
                      <Icon className="size-4.5" strokeWidth={1.5} />
                    </span>
                    <span>
                      <span className="block font-mono text-[10px] tracking-[0.24em] text-fog uppercase">
                        {channel.label}
                      </span>
                      <span className="mt-0.5 block text-[15px] font-medium text-bone">
                        {channel.value}
                      </span>
                    </span>
                  </>
                );
                return (
                  <li key={channel.label}>
                    {channel.href ? (
                      <a href={channel.href} className="group flex items-center gap-4">
                        {content}
                      </a>
                    ) : (
                      <div className="group flex items-center gap-4">{content}</div>
                    )}
                  </li>
                );
              })}
            </ul>
          </Reveal>

          <Reveal delay={0.25}>
            <p className="mt-10 flex items-center gap-2.5 font-mono text-[10px] tracking-[0.2em] text-fog/80 uppercase">
              <ShieldCheck className="size-4 text-signal" />
              Confidential assessments · No-obligation quotations
            </p>
          </Reveal>
        </div>

        {/* ── right column: the booking form ─────────────────────────────── */}
        <Reveal delay={0.15}>
          <div className="blueprint-dim relative border border-line bg-coal/70">
            {/* panel header */}
            <div className="flex items-center justify-between border-b border-line px-6 py-4 md:px-9">
              <span className="font-mono text-[10px] tracking-[0.26em] text-fog uppercase">
                Enquiry form — WD/2026
              </span>
              <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.26em] text-fog uppercase">
                <span className="size-1.5 animate-pulse-dot rounded-full bg-signal" />
                Online
              </span>
            </div>

            <AnimatePresence mode="wait">
              {status === "success" ? (
                /* ── success state ─────────────────────────────────────── */
                <motion.div
                  key="success"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5, ease: EASE }}
                  className="flex min-h-[540px] flex-col items-center justify-center px-8 py-12 text-center"
                >
                  <span className="grid size-16 place-items-center rounded-full border border-signal/40">
                    <CheckCircle2 className="size-7 text-signal" strokeWidth={1.5} />
                  </span>
                  <h3 className="mt-7 text-2xl font-semibold tracking-tight md:text-3xl">
                    Request received.
                  </h3>
                  <p className="mt-3 max-w-sm text-[15px] leading-relaxed text-fog">
                    Thank you{form.name ? `, ${form.name.split(" ")[0]}` : ""}. Our engineers will
                    review your message and contact you within one business day.
                  </p>
                  <span className="mt-6 border border-line px-4 py-2 font-mono text-[10px] tracking-[0.26em] text-fog uppercase">
                    Ref: WD-{String(refId ?? 0).padStart(4, "0")}
                  </span>
                  <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
                    <a
                      href={`tel:${SITE.phoneRaw}`}
                      className="inline-flex items-center gap-2 bg-signal px-6 py-3.5 font-mono text-[11px] font-semibold tracking-[0.16em] text-ink uppercase transition-colors hover:bg-bone"
                    >
                      <Phone className="size-4" /> Call us now
                    </a>
                    <button
                      onClick={resetForm}
                      className="inline-flex items-center gap-2 border border-line px-6 py-3.5 font-mono text-[11px] tracking-[0.16em] text-bone uppercase transition-colors hover:border-signal/60 hover:text-signal"
                    >
                      Send another enquiry
                    </button>
                  </div>
                </motion.div>
              ) : (
                /* ── the form itself ───────────────────────────────────── */
                <motion.form
                  key="form"
                  onSubmit={onSubmit}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, y: -14 }}
                  transition={{ duration: 0.5, ease: EASE }}
                  className="px-6 py-8 md:px-9 md:py-9"
                >
                  <div className="grid gap-x-6 gap-y-7 sm:grid-cols-2">
                    <div>
                      <label htmlFor="name" className={labelCls}>
                        Full name <span className="text-signal">*</span>
                      </label>
                      <input
                        id="name"
                        required
                        value={form.name}
                        onChange={update("name")}
                        placeholder="e.g. Kwame Mensah"
                        className={inputCls}
                        autoComplete="name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className={labelCls}>
                        Email address <span className="text-signal">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        required
                        value={form.email}
                        onChange={update("email")}
                        placeholder="you@example.com"
                        className={inputCls}
                        autoComplete="email"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className={labelCls}>
                        Phone number <span className="text-signal">*</span>
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        required
                        value={form.phone}
                        onChange={update("phone")}
                        placeholder="024 000 0000"
                        className={inputCls}
                        autoComplete="tel"
                      />
                    </div>
                    <div>
                      <label htmlFor="service" className={labelCls}>
                        Service needed <span className="text-signal">*</span>
                      </label>
                      <div className="relative">
                        <select
                          id="service"
                          required
                          value={form.service}
                          onChange={update("service")}
                          className={`${inputCls} appearance-none pr-8 ${form.service ? "" : "text-fog/40"}`}
                        >
                          <option value="" disabled className="bg-coal">
                            Select a service…
                          </option>
                          {SERVICES.map((s) => (
                            <option key={s.id} value={s.title} className="bg-coal text-bone">
                              {s.title}
                            </option>
                          ))}
                          <option value="Other / Not sure yet" className="bg-coal text-bone">
                            Other / Not sure yet
                          </option>
                        </select>
                        <ChevronDown className="pointer-events-none absolute top-1/2 right-1 size-4 -translate-y-1/2 text-fog" />
                      </div>
                    </div>
                    <div className="sm:col-span-2">
                      <label htmlFor="date" className={labelCls}>
                        Preferred site-visit date (optional)
                      </label>
                      <input
                        id="date"
                        type="date"
                        value={form.preferredDate}
                        onChange={update("preferredDate")}
                        min={new Date().toISOString().slice(0, 10)}
                        className={inputCls}
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label htmlFor="message" className={labelCls}>
                        Tell us about the project <span className="text-signal">*</span>
                      </label>
                      <textarea
                        id="message"
                        required
                        rows={4}
                        value={form.message}
                        onChange={update("message")}
                        placeholder="Location of the plot or building, what you want to build or check, your timeline…"
                        className={`${inputCls} resize-none`}
                      />
                    </div>
                  </div>

                  {status === "error" && error && (
                    <p role="alert" className="mt-6 border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
                      {error}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={status === "sending"}
                    className="group mt-9 flex w-full items-center justify-center gap-2 bg-signal px-6 py-4 font-mono text-[11px] font-semibold tracking-[0.18em] text-ink uppercase transition-colors duration-300 hover:bg-bone disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {status === "sending" ? (
                      <>
                        <Loader2 className="size-4 animate-spin" /> Sending…
                      </>
                    ) : (
                      <>
                        Send enquiry
                        <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </>
                    )}
                  </button>
                  <p className="mt-4 text-center font-mono text-[10px] tracking-[0.14em] text-fog/70">
                    We reply within one business day · Your details stay private
                  </p>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
