import Image from "next/image";
import { ArrowUpRight, Plus } from "lucide-react";
import { IMAGES } from "@/lib/site";
import { Reveal } from "./reveal";
import { SectionTag } from "./section-tag";

// "04 / FIELDWORK" — a sample portfolio grid. Replace entries in
// IMAGES.projects (src/lib/site.ts) with the company's real projects.
export function Projects() {
  const cards = [
    { project: IMAGES.projects[0], span: "lg:col-span-7", aspect: "aspect-[16/10]" },
    { project: IMAGES.projects[1], span: "lg:col-span-5", aspect: "aspect-[16/10]" },
    { project: IMAGES.projects[2], span: "lg:col-span-12", aspect: "aspect-[16/10] lg:aspect-[21/8]" },
  ];

  return (
    <section id="projects" className="scroll-mt-20 border-t border-line py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-8">
          <div>
            <Reveal>
              <SectionTag index="05" title="Fieldwork" />
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-8 text-3xl leading-[1.1] font-semibold tracking-[-0.01em] md:text-5xl">
                Selected engagements.
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.15}>
            <p className="max-w-xs font-mono text-[10px] leading-relaxed tracking-[0.2em] text-fog/70 uppercase">
              Sample portfolio — full references available on request
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-6 md:mt-16 lg:grid-cols-12">
          {cards.map(({ project, span, aspect }, i) => (
            <Reveal key={project.title} delay={i * 0.08} className={span}>
              <a href="#contact" className="group relative block overflow-hidden border border-line">
                <Image
                  src={project.src}
                  alt={project.title}
                  width={1200}
                  height={750}
                  className={`w-full object-cover grayscale transition-all duration-700 ease-out group-hover:scale-[1.04] group-hover:grayscale-0 ${aspect}`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent" />
                <Plus className="absolute top-2.5 left-2.5 size-4 text-signal/80" />
                <Plus className="absolute top-2.5 right-2.5 size-4 text-signal/80" />
                <span className="absolute top-3.5 left-1/2 -translate-x-1/2 font-mono text-[9px] tracking-[0.3em] text-bone/50 uppercase">
                  WD-{String(i + 1).padStart(3, "0")}
                </span>
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 md:p-7">
                  <div>
                    <p className="font-mono text-[10px] tracking-[0.24em] text-signal uppercase">
                      {project.tag}
                    </p>
                    <h3 className="mt-2 text-xl font-semibold tracking-tight text-bone md:text-2xl">
                      {project.title}
                    </h3>
                    <p className="mt-1.5 font-mono text-[10px] tracking-[0.2em] text-fog uppercase">
                      {project.place} · {project.year}
                    </p>
                  </div>
                  <span className="grid size-11 shrink-0 place-items-center border border-line bg-ink/60 text-bone backdrop-blur transition-colors duration-300 group-hover:border-signal group-hover:bg-signal group-hover:text-ink">
                    <ArrowUpRight className="size-4" />
                  </span>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
