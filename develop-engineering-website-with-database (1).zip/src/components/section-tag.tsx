// A tiny "blueprint label" used at the top of every section, e.g. "02 / SERVICES"
// tone="dark"  → for the dark ink sections (default)
// tone="light" → for the warm paper sections (testimonials / FAQ)
export function SectionTag({
  index,
  title,
  tone = "dark",
}: {
  index: string;
  title: string;
  tone?: "dark" | "light";
}) {
  const muted = tone === "dark" ? "text-fog" : "text-ink/55";
  const line = tone === "dark" ? "bg-line" : "bg-paperline";

  return (
    <div className="flex items-center gap-4 font-mono text-[11px] font-medium tracking-[0.3em] uppercase">
      <span className={tone === "dark" ? "text-signal" : "text-amberdeep"}>{index}</span>
      <span className={muted}>/</span>
      <span className={muted}>{title}</span>
      <span className={`h-px w-12 sm:w-20 ${line}`} />
      <span className={`size-1.5 rotate-45 border ${tone === "dark" ? "border-signal/70" : "border-amberdeep/70"}`} />
    </div>
  );
}
