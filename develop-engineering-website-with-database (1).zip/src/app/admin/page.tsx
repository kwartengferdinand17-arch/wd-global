import { desc } from "drizzle-orm";
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Inbox,
  Mail,
  Phone,
} from "lucide-react";
import { db } from "@/db";
import { enquiries, type Enquiry } from "@/db/schema";

// ─────────────────────────────────────────────────────────────────────────────
// THE ADMIN INBOX — open /admin in the browser to see every booking/message
// visitors have sent. The data is read straight from the PostgreSQL database.
// ─────────────────────────────────────────────────────────────────────────────
export const dynamic = "force-dynamic";

export const metadata = {
  title: "Enquiries inbox — WD Global Engineering Consult Limited",
};

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export default async function AdminPage() {
  let rows: Enquiry[] = [];
  let loadError: string | null = null;

  try {
    rows = await db.select().from(enquiries).orderBy(desc(enquiries.createdAt));
  } catch (error) {
    console.error("[/admin] could not load enquiries:", error);
    loadError =
      "Could not load enquiries. If this is a fresh setup, run `npx drizzle-kit push` to create the database table first.";
  }

  const newCount = rows.filter((r) => r.status === "new").length;

  return (
    <main className="blueprint min-h-screen">
      {/* top bar */}
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 md:px-8">
          <a
            href="/"
            className="flex items-center gap-2 font-mono text-[11px] tracking-[0.22em] text-fog uppercase transition-colors hover:text-signal"
          >
            <ArrowLeft className="size-4" /> Back to site
          </a>
          <span className="font-mono text-[10px] tracking-[0.3em] text-fog/70 uppercase">
            WD Global — Admin
          </span>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-12 md:px-8 md:py-16">
        {/* heading + counters */}
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="flex items-center gap-2.5 font-mono text-[11px] tracking-[0.3em] text-signal uppercase">
              <Inbox className="size-4" /> Database — enquiries table
            </p>
            <h1 className="mt-4 text-3xl font-semibold tracking-tight md:text-5xl">
              Enquiries inbox.
            </h1>
          </div>
          <div className="flex gap-3 font-mono text-[10px] tracking-[0.2em] uppercase">
            <span className="border border-line px-4 py-2.5 text-fog">
              Total — <span className="text-bone">{rows.length}</span>
            </span>
            <span className="border border-signal/40 bg-signal/10 px-4 py-2.5 text-signal">
              New — {newCount}
            </span>
          </div>
        </div>

        {/* error / empty / list states */}
        {loadError ? (
          <div className="mt-12 flex items-start gap-4 border border-red-500/30 bg-red-500/10 p-6">
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-red-400" />
            <div>
              <p className="font-semibold text-red-200">Database not reachable</p>
              <p className="mt-1 font-mono text-xs leading-relaxed text-red-300/80">{loadError}</p>
            </div>
          </div>
        ) : rows.length === 0 ? (
          <div className="mt-12 border border-dashed border-line bg-coal/40 px-8 py-20 text-center">
            <Inbox className="mx-auto size-10 text-fog/50" strokeWidth={1.2} />
            <p className="mt-5 text-lg font-semibold text-bone">No enquiries yet</p>
            <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-fog">
              Submit the booking form on the homepage and the message will appear here — saved in
              the PostgreSQL database.
            </p>
            <a
              href="/#contact"
              className="mt-7 inline-flex items-center gap-2 bg-signal px-6 py-3.5 font-mono text-[11px] font-semibold tracking-[0.16em] text-ink uppercase transition-colors hover:bg-bone"
            >
              Open the booking form
            </a>
          </div>
        ) : (
          <ul className="mt-12 space-y-5">
            {rows.map((row) => (
              <li key={row.id} className="border border-line bg-coal/50 p-5 md:p-7">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <h2 className="text-lg font-semibold text-bone">{row.name}</h2>
                    <span
                      className={`px-2.5 py-1 font-mono text-[9px] tracking-[0.2em] uppercase ${
                        row.status === "new"
                          ? "bg-signal text-ink"
                          : "border border-line text-fog"
                      }`}
                    >
                      {row.status}
                    </span>
                  </div>
                  <span className="font-mono text-[10px] tracking-[0.16em] text-fog/70 uppercase">
                    WD-{String(row.id).padStart(4, "0")} · {formatDate(row.createdAt)}
                  </span>
                </div>

                <div className="mt-3.5 flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-xs text-fog">
                  <a href={`tel:${row.phone}`} className="flex items-center gap-2 transition-colors hover:text-signal">
                    <Phone className="size-3.5 text-signal" /> {row.phone}
                  </a>
                  <a href={`mailto:${row.email}`} className="flex items-center gap-2 transition-colors hover:text-signal">
                    <Mail className="size-3.5 text-signal" /> {row.email}
                  </a>
                  {row.preferredDate && (
                    <span className="flex items-center gap-2">
                      <Calendar className="size-3.5 text-signal" /> Visit: {row.preferredDate}
                    </span>
                  )}
                </div>

                <div className="mt-5 border-t border-line pt-5">
                  <p className="font-mono text-[10px] tracking-[0.24em] text-signal uppercase">
                    {row.service}
                  </p>
                  <p className="mt-2.5 max-w-3xl text-sm leading-relaxed text-fog">{row.message}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
