import { Navbar } from "@/components/navbar";
import { Hero } from "@/components/hero";
import { Marquee } from "@/components/marquee";
import { About } from "@/components/about";
import { Services } from "@/components/services";
import { WhyUs } from "@/components/why-us";
import { Process } from "@/components/process";
import { Projects } from "@/components/projects";
import { Testimonials } from "@/components/testimonials";
import { Faq } from "@/components/faq";
import { CtaBanner } from "@/components/cta-banner";
import { Contact } from "@/components/contact";
import { Footer } from "@/components/footer";
import { FloatingActions } from "@/components/floating-actions";

// ─────────────────────────────────────────────────────────────────────────────
// THE HOMEPAGE — this file only arranges the sections, top to bottom.
// Want a different order? Just move the lines around.
// ─────────────────────────────────────────────────────────────────────────────
export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="relative">
        <Hero />
        <Marquee />
        <About />
        <Services />
        <WhyUs />
        <Process />
        <Projects />
        <Testimonials />
        <Faq />
        <CtaBanner />
        <Contact />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}
