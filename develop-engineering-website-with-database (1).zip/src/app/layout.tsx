import type { Metadata } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Mono, Space_Grotesk } from "next/font/google";
import "./globals.css";

// Load the two website fonts and expose them as CSS variables.
const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
});

const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-plex",
});

// ── SEO settings (what Google + WhatsApp link previews show) ────────────────
export const metadata: Metadata = {
  title: "WD Global Engineering Consult Limited — Engineering Consultancy in Kumasi, Ghana",
  description:
    "Civil & structural engineering, architectural design, construction supervision and project management. Estate Kwadaso, near Police Hospital, Kumasi. Call 024 471 0770.",
  keywords: [
    "engineering consultancy Ghana",
    "civil engineering Kumasi",
    "structural engineer Kwadaso",
    "construction supervision Ghana",
    "WD Global Engineering",
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${grotesk.variable} ${plex.variable}`}>
      <body className="bg-ink font-display text-bone antialiased">{children}</body>
    </html>
  );
}
