import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { enquiries } from "@/db/schema";

// ─────────────────────────────────────────────────────────────────────────────
// API ROUTE: POST /api/enquiries
// The booking form sends its data here. We check it with zod, then save it
// into the PostgreSQL database using Drizzle ORM.
// ─────────────────────────────────────────────────────────────────────────────
const enquirySchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name").max(120),
  email: z.string().trim().email("Please enter a valid email address").max(160),
  phone: z.string().trim().min(7, "Please enter a valid phone number").max(40),
  service: z.string().trim().min(2, "Please choose a service").max(80),
  preferredDate: z.string().trim().max(40).optional().or(z.literal("")),
  message: z.string().trim().min(10, "Please tell us a little more (10+ characters)").max(2000),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // 1. Validate the incoming data
    const parsed = enquirySchema.safeParse(body);
    if (!parsed.success) {
      const firstIssue = parsed.error.issues[0];
      return NextResponse.json(
        { ok: false, error: firstIssue?.message ?? "Invalid form data" },
        { status: 400 },
      );
    }

    // 2. Save it in the database
    const data = parsed.data;
    const [row] = await db
      .insert(enquiries)
      .values({
        name: data.name,
        email: data.email,
        phone: data.phone,
        service: data.service,
        preferredDate: data.preferredDate || null,
        message: data.message,
      })
      .returning({ id: enquiries.id });

    // 3. Confirm success to the browser
    return NextResponse.json(
      { ok: true, id: row.id, message: "Enquiry received. We will get back to you shortly." },
      { status: 201 },
    );
  } catch (error) {
    console.error("[POST /api/enquiries]", error);
    return NextResponse.json(
      { ok: false, error: "Something went wrong on our side. Please call us directly on 024 471 0770." },
      { status: 500 },
    );
  }
}
