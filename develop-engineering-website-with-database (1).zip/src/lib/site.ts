// ─────────────────────────────────────────────────────────────────────────────
// SITE SETTINGS — this is the ONE file you edit to change business details.
// Every phone number, email, image or service on the website reads from here.
// ─────────────────────────────────────────────────────────────────────────────

export const SITE = {
  name: "WD Global Engineering Consult Limited",
  shortName: "WD Global Engineering",
  monogram: "WD",
  tagline: "Engineering precision for the built environment",

  // Contact details
  phoneLocal: "024 471 0770", // shown on the site
  phoneRaw: "+233244710770", // used by the tel: link (no spaces)
  email: "wdglobalengineering@gmail.com",
  location: "Estate Kwadaso, near Police Hospital",
  city: "Kumasi — Ghana",

  // Office hours
  hours: "Mon – Sat · 8:00 AM – 5:00 PM",
} as const;

// Services offered — edit this list to add/remove what the company does.
export const SERVICES = [
  {
    id: "01",
    title: "Civil & Structural Engineering",
    text: "Structural analysis, design and detailing of residential, commercial and industrial structures — safe, economical and code-compliant.",
    icon: "Landmark",
  },
  {
    id: "02",
    title: "Architectural Design & Planning",
    text: "Concept to working drawings: floor plans, 3D visuals and full permit documentation designed around your budget and vision.",
    icon: "PenTool",
  },
  {
    id: "03",
    title: "Construction Supervision",
    text: "Resident site supervision and quality control that keeps workmanship, materials and safety exactly to specification.",
    icon: "HardHat",
  },
  {
    id: "04",
    title: "Project Management & Costing",
    text: "Bills of quantities, tendering, scheduling and contract administration that protect your money and your timeline.",
    icon: "ClipboardCheck",
  },
  {
    id: "05",
    title: "Land Surveying & Geotechnics",
    text: "Cadastral and topographic surveys, site investigations and soil testing that de-risk every foundation decision.",
    icon: "MapPinned",
  },
  {
    id: "06",
    title: "Electrical & Mechanical Services",
    text: "Power, lighting, plumbing, HVAC and fire-safety systems engineered and coordinated as one integrated build.",
    icon: "Cable",
  },
] as const;

// Images used across the site — the files live in the public/images folder.
// "/images/hero.jpg" means "look inside public/images" — works ONLINE and OFFLINE.
// To use the company's real photos: copy your photo into public/images and
// write its name here, e.g. "/images/our-office.jpg".
export const IMAGES = {
  hero: "/images/hero.jpg",
  about: "/images/about.jpg",
  projects: [
    {
      src: "/images/project-1.jpg",
      title: "Ridgeview Estate Development",
      tag: "Residential · Structural",
      place: "Kwadaso, Kumasi",
      year: "2024",
    },
    {
      src: "/images/project-2.jpg",
      title: "Anwomaso Commercial Complex",
      tag: "Commercial · Design + Supervision",
      place: "Anwomaso, Kumasi",
      year: "2023",
    },
    {
      src: "/images/project-3.jpg",
      title: "Tech Junction Office Park",
      tag: "Civil · Roads & Drainage",
      place: "Kumasi",
      year: "2022",
    },
  ],
} as const;

// Developer credit shown in the footer — tells visitors who built the site
export const CREDITS = {
  email: "kwartengferdinard79@gmail.com",
  phoneLocal: "050 874 3755", // displayed on the site
  phoneRaw: "+233508743755", // used by the tel: link (no spaces)
} as const;

// Track-record numbers shown in the stats strip.
export const STATS = [
  { value: 120, suffix: "+", label: "Projects delivered" },
  { value: 40, suffix: "+", label: "Clients served" },
  { value: 98, suffix: "%", label: "On-time completion" },
  { value: 12, suffix: "", label: "Engineering specialists" },
] as const;

// The step-by-step way the company works with a client.
export const PROCESS = [
  {
    id: "01",
    title: "Discovery Call",
    text: "A free 30-minute conversation — by phone, on site or online — to understand your project, budget and goals.",
  },
  {
    id: "02",
    title: "Site & Feasibility Assessment",
    text: "We visit the land, review documents and flag risks early: soil, access, drainage, permits and utilities.",
  },
  {
    id: "03",
    title: "Design, Engineering & Costing",
    text: "Drawings, structural calculations and a transparent bill of quantities so you know the cost before we build.",
  },
  {
    id: "04",
    title: "Approvals & Permits",
    text: "We prepare and pursue all documentation — building permits and statutory approvals handled end to end.",
  },
  {
    id: "05",
    title: "Construction Support & Handover",
    text: "Site supervision, stage inspections and a final quality audit before we hand you the keys.",
  },
] as const;

export const NAV_LINKS = [
  { label: "Practice", href: "#practice" },
  { label: "Services", href: "#services" },
  { label: "Process", href: "#process" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
] as const;

// ─────────────────────────────────────────────────────────────────────────────
// EXTRA CONTENT — testimonials, FAQs, why-choose-us points and more photos.
// Edit these lists to make the site truly yours.
// ─────────────────────────────────────────────────────────────────────────────

// More photos (team shot + the big call-to-action banner) — also local files
export const EXTRA_IMAGES = {
  team: "/images/team.jpg",
  banner: "/images/banner.jpg",
} as const;

// "Why choose us" selling points
export const WHY_POINTS = [
  {
    title: "One accountable team",
    text: "Design, costing, permits and supervision under one roof — never chase five different consultants again.",
  },
  {
    title: "Transparent pricing",
    text: "Itemised bills of quantities before work begins. You approve every cedi before it is spent.",
  },
  {
    title: "Engineer-led supervision",
    text: "Qualified engineers on site, not just overseers — errors are corrected before they become costs.",
  },
  {
    title: "Documented quality",
    text: "Photo reports and stage certificates at every milestone, so you can follow progress from anywhere.",
  },
  {
    title: "Local expertise",
    text: "Deep working knowledge of Kumasi assemblies, the permit process and local soil conditions.",
  },
] as const;

// Trust badges shown under the "Why us" section
export const CERTS = [
  "GhIE Member Firm",
  "Registered Engineers",
  "Fully Insured Works",
  "ISO-aligned QA",
] as const;

// Client testimonials — replace with real words from your clients.
// Avatars are also local files in public/images.
export const TESTIMONIALS = [
  {
    quote:
      "WD Global turned our drawings into a home we are proud of. The weekly photo reports meant we never once wondered what was happening on site.",
    name: "Abena Owusu",
    role: "Homeowner · Kwadaso Estate",
    avatar: "/images/avatar-1.jpg",
  },
  {
    quote:
      "Their bill of quantities was so detailed the bank approved our facility in two weeks. Professional from the very first meeting.",
    name: "Daniel Appiah",
    role: "Property Developer · Kumasi",
    avatar: "/images/avatar-2.jpg",
  },
  {
    quote:
      "They caught a foundation error on day one that would have cost us hundreds of thousands later. Worth every pesewa.",
    name: "Nana Yaa Boateng",
    role: "Guesthouse Owner · Asokwa",
    avatar: "/images/avatar-3.jpg",
  },
] as const;

// Frequently asked questions — answered like a professional
export const FAQS = [
  {
    q: "How much does the first consultation cost?",
    a: "Nothing. Your first 30-minute discovery call or meeting is completely free. After we understand your project, you receive a written, fixed quotation before any paid work begins.",
  },
  {
    q: "I only have a plot of land. How do we start?",
    a: "Perfect starting point. We visit the site, check the documents, run soil and topographic tests, then advise you on what the land can safely and legally carry — before you spend on drawings.",
  },
  {
    q: "Do you handle building permits and approvals?",
    a: "Yes, end to end. We prepare the drawings and documentation, submit to the municipal assembly and follow up until your permit is issued.",
  },
  {
    q: "Will I need to visit the site every day?",
    a: "No. Our engineers supervise the works daily and send you photo reports at each stage. You only come for scheduled milestone inspections — or follow everything from abroad.",
  },
  {
    q: "Which areas do you serve?",
    a: "We are based in Kwadaso, Kumasi, and serve the whole Ashanti Region. For larger commercial and institutional projects we work nationwide.",
  },
  {
    q: "How long does a typical house design take?",
    a: "Concept drawings take one to two weeks once we agree the brief. Full working drawings with structural details and permits typically take three to five weeks.",
  },
] as const;
